@echo off
cd /d "%~dp0"
set "PORT=8787"

set "NODE_EXE="
if exist "C:\Program Files\nodejs\node.exe" set "NODE_EXE=C:\Program Files\nodejs\node.exe"
if not defined NODE_EXE if exist "C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe" set "NODE_EXE=C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe"
if not defined NODE_EXE if exist "C:\Program Files\Common Files\Adobe\Creative Cloud Libraries\libs\node.exe" set "NODE_EXE=C:\Program Files\Common Files\Adobe\Creative Cloud Libraries\libs\node.exe"

if defined NODE_EXE (
  "%NODE_EXE%" "%~dp0server.js"
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Mobile.ps1" -Port %PORT%
)

pause
