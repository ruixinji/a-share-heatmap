const app = getApp();

const SORTS = [
  { label: "按涨幅", value: "pct" },
  { label: "按成交额", value: "amount" },
  { label: "按主力", value: "mainNet" },
  { label: "按换手", value: "turnover" }
];

function numeric(value, fallback = 0) {
  if (value === "-" || value === undefined || value === null || Number.isNaN(Number(value))) return fallback;
  return Number(value);
}

function signed(value, digits = 2) {
  if (value === "-" || value === undefined || value === null || Number.isNaN(Number(value))) return "-";
  const n = Number(value);
  return `${n > 0 ? "+" : ""}${n.toFixed(digits)}`;
}

function money(value) {
  if (value === "-" || value === undefined || value === null || Number.isNaN(Number(value))) return "-";
  const n = Number(value);
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 100000000) return `${sign}${(abs / 100000000).toFixed(2)}亿`;
  if (abs >= 10000) return `${sign}${(abs / 10000).toFixed(1)}万`;
  return `${Math.round(n)}`;
}

function tone(value) {
  const n = numeric(value);
  if (n > 0.2) return "up";
  if (n < -0.2) return "down";
  return "flat";
}

function heatColor(value) {
  const pct = numeric(value);
  if (pct >= 7) return "#b8001f";
  if (pct >= 4) return "#9b1426";
  if (pct >= 2) return "#7f1d2c";
  if (pct > 0.2) return "#5c2730";
  if (pct <= -7) return "#067a3c";
  if (pct <= -4) return "#0b6838";
  if (pct <= -2) return "#165637";
  if (pct < -0.2) return "#263f37";
  return "#333943";
}

Page({
  data: {
    type: "concept",
    status: "正在连接行情...",
    indices: [],
    boards: [],
    visibleBoards: [],
    keyword: "",
    selected: {},
    stocks: [],
    boardMeta: "点击热力图色块查看成分股",
    marketStats: {},
    sortLabels: SORTS.map((item) => item.label),
    sortIndex: 0,
    adUnitId: app.globalData.adUnitId
  },

  onLoad() {
    this.refreshMarket();
  },

  onPullDownRefresh() {
    this.refreshMarket().finally(() => wx.stopPullDownRefresh());
  },

  request(path) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: `${app.globalData.apiBase}${path}`,
        method: "GET",
        timeout: 20000,
        success: (res) => {
          if (res.data && res.data.ok) resolve(res.data);
          else reject(new Error(res.data?.error || `请求失败 ${res.statusCode}`));
        },
        fail: reject
      });
    });
  },

  formatBoard(row, grow) {
    return {
      ...row,
      pctText: signed(row.pct),
      amountText: money(row.amount),
      tone: tone(row.pct),
      bg: heatColor(row.pct),
      grow
    };
  },

  applyFilter() {
    const q = this.data.keyword.trim().toLowerCase();
    const rows = q
      ? this.data.boards.filter((row) => `${row.name}${row.code}`.toLowerCase().includes(q))
      : this.data.boards;
    const sliced = rows.slice(0, 160);
    const amounts = sliced.map((row) => Math.max(numeric(row.amount), 1));
    const min = Math.log10(Math.min(...amounts, 1));
    const max = Math.log10(Math.max(...amounts, 10));
    const span = Math.max(max - min, 1);
    const visibleBoards = sliced.map((row) => {
      const score = (Math.log10(Math.max(numeric(row.amount), 1)) - min) / span;
      return this.formatBoard(row, Math.round(8 + score * 32));
    });
    this.setData({ visibleBoards });
  },

  async refreshMarket() {
    this.setData({ status: "更新中..." });
    try {
      const data = await this.request(`/api/market?type=${this.data.type}`);
      const boards = data.data.boards || [];
      const indices = (data.data.indices || []).map((row) => ({
        ...row,
        pctText: signed(row.pct),
        changeText: signed(row.change),
        tone: tone(row.pct)
      }));
      const up = boards.filter((row) => numeric(row.pct) > 0.2).length;
      const down = boards.filter((row) => numeric(row.pct) < -0.2).length;
      this.setData({
        boards,
        indices,
        marketStats: { up, down, total: data.data.stats?.total },
        status: `已更新 ${new Date(data.time).toLocaleTimeString()}`
      });
      this.applyFilter();
      if (!this.data.selected.code && boards[0]) {
        this.setData({ selected: { code: boards[0].code, name: boards[0].name } });
        this.loadStocks();
      }
    } catch (error) {
      this.setData({ status: `更新失败：${error.message}` });
    }
  },

  changeType(event) {
    const type = event.currentTarget.dataset.type;
    this.setData({ type, selected: {}, stocks: [], boardMeta: "点击热力图色块查看成分股" });
    this.refreshMarket();
  },

  onSearch(event) {
    this.setData({ keyword: event.detail.value });
    this.applyFilter();
  },

  selectBoard(event) {
    const { code, name } = event.currentTarget.dataset;
    this.setData({ selected: { code, name }, stocks: [], boardMeta: "正在加载成分股..." });
    this.loadStocks();
  },

  changeSort(event) {
    this.setData({ sortIndex: Number(event.detail.value) });
    this.loadStocks();
  },

  async loadStocks() {
    if (!this.data.selected.code) return;
    try {
      const sort = SORTS[this.data.sortIndex].value;
      const data = await this.request(`/api/board/${this.data.selected.code}/stocks?sort=${sort}&order=desc`);
      const stocks = (data.data || []).slice(0, 80).map((row) => ({
        ...row,
        pctText: signed(row.pct),
        amountText: money(row.amount),
        tone: tone(row.pct)
      }));
      this.setData({
        stocks,
        boardMeta: `${this.data.selected.code} · ${stocks.length} 只 · ${new Date(data.time).toLocaleTimeString()}`
      });
    } catch (error) {
      this.setData({ boardMeta: `加载失败：${error.message}` });
    }
  }
});
