param(
  [int]$Port = 8787,
  [switch]$NoOpen
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Public = Join-Path $Root "public"
$Prefix = "http://localhost:$Port/"
$Headers = @{
  Referer = "https://quote.eastmoney.com/"
  "User-Agent" = "Mozilla/5.0"
}
$BoardFields = "f12,f14,f2,f3,f4,f5,f6,f7,f8,f20,f62,f104,f105,f106"
$StockFields = "f12,f14,f2,f3,f4,f5,f6,f7,f8,f9,f10,f15,f16,f17,f18,f20,f21,f23,f62,f100"
$IndexFields = "f12,f14,f2,f3,f4,f5,f6"
$AShareFs = "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23"
$IndexSecids = "1.000001,0.399001,0.399006,0.000300,0.000905,1.000688"
$CustomBoards = @{
  ZTKJ = @{
    code = "ZTKJ"
    name = "ZTKJ"
    sourceBoards = @("BK1136", "BK1128", "BK1168", "BK0711", "BK1120", "BK0709", "BK0428", "BK0989", "BK0595", "BK0729")
    fixedSecids = @("1.600522", "0.000063", "0.000988", "0.002281", "0.002463", "0.002384", "0.300308", "0.300502", "0.300394", "0.300570", "0.300476", "1.601179", "1.600312", "1.600406", "0.002028", "1.600487", "0.002498")
  }
}

function Convert-Row($row) {
  [ordered]@{
    price = $row.f2
    pct = $row.f3
    change = $row.f4
    volume = $row.f5
    amount = $row.f6
    amplitude = $row.f7
    turnover = $row.f8
    pe = $row.f9
    volumeRatio = $row.f10
    code = $row.f12
    name = $row.f14
    high = $row.f15
    low = $row.f16
    open = $row.f17
    prevClose = $row.f18
    marketCap = $row.f20
    floatMarketCap = $row.f21
    pb = $row.f23
    mainNet = $row.f62
    industry = $row.f100
    riseCount = $row.f104
    fallCount = $row.f105
    flatCount = $row.f106
  }
}

function Send-Text($Response, [int]$Status, [string]$Body, [string]$ContentType) {
  $bytes = [Text.Encoding]::UTF8.GetBytes($Body)
  $Response.StatusCode = $Status
  $Response.ContentType = $ContentType
  $Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Response.Close()
}

function Send-Json($Response, [int]$Status, $Payload) {
  $json = $Payload | ConvertTo-Json -Depth 12 -Compress
  Send-Text $Response $Status $json "application/json; charset=utf-8"
}

function Get-BoardFs([string]$Type) {
  if ($Type -eq "industry") { return "m:90+t:2" }
  return "m:90+t:3"
}

function Convert-Number($Value, [double]$Fallback = 0) {
  if ($null -eq $Value -or $Value -eq "-") { return $Fallback }
  try { return [double]$Value } catch { return $Fallback }
}

function Clamp([double]$Value, [double]$Min = 0, [double]$Max = 1) {
  return [Math]::Max($Min, [Math]::Min($Max, $Value))
}

function Scale([double]$Value, [double]$Min, [double]$Max) {
  return Clamp (($Value - $Min) / ($Max - $Min)) 0 1
}

function Get-MarketPrefix([string]$Code) {
  if ($Code.StartsWith("6")) { return "1" }
  return "0"
}

function Invoke-Eastmoney($Url) {
  $lastError = $null
  for ($i = 0; $i -lt 4; $i++) {
    try {
      return Invoke-RestMethod -Uri $Url -Headers $Headers -TimeoutSec 12
    } catch {
      $lastError = $_.Exception
      Start-Sleep -Milliseconds (350 * ($i + 1))
    }
  }
  throw $lastError
}

function Get-Boards([string]$Type, [string]$Keyword, [int]$Limit) {
  $rows = @()
  $fs = [uri]::EscapeDataString((Get-BoardFs $Type))
  for ($page = 1; $page -le 12; $page++) {
    $url = "https://push2delay.eastmoney.com/api/qt/clist/get?pn=$page&pz=100&po=1&np=1&fltt=2&invt=2&fid=f3&fs=$fs&fields=$BoardFields"
    try {
      $data = Invoke-Eastmoney $url
      if ($null -eq $data.data.diff) { continue }
      foreach ($item in $data.data.diff) { $rows += Convert-Row $item }
      if ($rows.Count -ge $Limit) { break }
      if ($rows.Count -ge [int]$data.data.total) { break }
    } catch {
      continue
    }
  }
  if ($Keyword) {
    $lower = $Keyword.ToLower()
    $rows = @($rows | Where-Object { (($_.name + $_.code).ToLower()).Contains($lower) })
  }
  return @($rows | Select-Object -First $Limit)
}

function Get-Indices {
  $secids = [uri]::EscapeDataString($IndexSecids)
  $url = "https://push2.eastmoney.com/api/qt/ulist.np/get?secids=$secids&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fields=$IndexFields"
  $data = Invoke-Eastmoney $url
  $rows = @()
  if ($null -ne $data.data.diff) {
    foreach ($item in $data.data.diff) { $rows += Convert-Row $item }
  }
  return $rows
}

function Get-AshareStats {
  $fs = [uri]::EscapeDataString($AShareFs)
  $url = "https://push2delay.eastmoney.com/api/qt/clist/get?pn=1&pz=1&po=1&np=1&fltt=2&invt=2&fid=f3&fs=$fs&fields=f3"
  $data = Invoke-Eastmoney $url
  return @{ total = [int]$data.data.total }
}

function Get-BoardStocks([string]$Code, [string]$Sort, [string]$Order) {
  if ($CustomBoards.ContainsKey($Code)) {
    return Get-CustomBoardStocks $Code $Sort $Order
  }

  $sortField = switch ($Sort) {
    "amount" { "f6" }
    "turnover" { "f8" }
    "mainNet" { "f62" }
    "price" { "f2" }
    default { "f3" }
  }
  $po = if ($Order -eq "asc") { "0" } else { "1" }
  $fs = [uri]::EscapeDataString("b:$Code")
  $url = "https://push2delay.eastmoney.com/api/qt/clist/get?pn=1&pz=300&po=$po&np=1&fltt=2&invt=2&fid=$sortField&fs=$fs&fields=$StockFields"
  $data = Invoke-Eastmoney $url
  $rows = @()
  if ($null -ne $data.data.diff) {
    foreach ($item in $data.data.diff) { $rows += Convert-Row $item }
  }
  return $rows
}

function Get-SecidStocks($Secids) {
  if ($Secids.Count -eq 0) { return @() }
  $joined = [uri]::EscapeDataString(($Secids -join ","))
  $url = "https://push2.eastmoney.com/api/qt/ulist.np/get?secids=$joined&ut=bd1d9ddb04089700cf9c27f6f7426281&fltt=2&invt=2&fields=$StockFields"
  $data = Invoke-Eastmoney $url
  $rows = @()
  if ($null -ne $data.data.diff) {
    foreach ($item in $data.data.diff) { $rows += Convert-Row $item }
  }
  return $rows
}

function Get-CustomBoardStocks([string]$Code, [string]$Sort, [string]$Order) {
  $board = $CustomBoards[$Code]
  $all = @()
  foreach ($boardCode in $board.sourceBoards) {
    try { $all += Get-BoardStocks $boardCode "pct" "desc" } catch { }
  }
  try { $all += Get-SecidStocks $board.fixedSecids } catch { }

  $seen = @{}
  $unique = @()
  foreach ($row in $all) {
    if ($null -eq $row.code -or $seen.ContainsKey($row.code)) { continue }
    $seen[$row.code] = $true
    $unique += $row
  }

  $key = switch ($Sort) {
    "amount" { "amount" }
    "turnover" { "turnover" }
    "mainNet" { "mainNet" }
    "price" { "price" }
    default { "pct" }
  }

  $sorted = $unique | Sort-Object -Property {
    $value = $_[$key]
    if ($null -eq $value -or $value -eq "-") { [double]::NegativeInfinity } else { [double]$value }
  } -Descending:($Order -ne "asc")
  return @($sorted)
}

function Get-ActiveAsharePool {
  $rows = @()
  $fs = [uri]::EscapeDataString($AShareFs)
  $seen = @{}
  foreach ($fid in @("f6", "f3", "f62", "f8")) {
    for ($page = 1; $page -le 2; $page++) {
      $url = "https://push2delay.eastmoney.com/api/qt/clist/get?pn=$page&pz=200&po=1&np=1&fltt=2&invt=2&fid=$fid&fs=$fs&fields=$StockFields"
      $data = Invoke-Eastmoney $url
      if ($null -eq $data.data.diff) { continue }
      foreach ($item in $data.data.diff) {
        $row = Convert-Row $item
        if ($null -eq $row.code -or $seen.ContainsKey($row.code)) { continue }
        $seen[$row.code] = $true
        $rows += $row
      }
      if (($page * 200) -ge [int]$data.data.total) { break }
    }
  }
  return $rows
}

function Get-CandidateScore($row) {
  $pct = Convert-Number $row.pct
  $amount = Convert-Number $row.amount
  $turnover = Convert-Number $row.turnover
  $mainNet = Convert-Number $row.mainNet
  $volumeRatio = Convert-Number $row.volumeRatio
  $amplitude = Convert-Number $row.amplitude
  $mainRatio = if ($amount -gt 0) { ($mainNet / $amount) * 100 } else { 0 }

  $riseCore = if ($pct -gt 0) { Scale $pct 1.5 7.5 } else { 0 }
  $risePenalty = if ($pct -gt 9.2) { 0.78 } else { 1 }
  $pctScore = 30 * $riseCore * $risePenalty
  $mainScore = 30 * (Clamp ((Scale $mainNet 0 350000000) * 0.65 + (Scale $mainRatio 0 9) * 0.35) 0 1)
  $amountScore = 18 * (Scale ([Math]::Log10([Math]::Max($amount, 1))) ([Math]::Log10(300000000)) ([Math]::Log10(12000000000)))
  $turnoverScore = if ($turnover -le 18) {
    16 * (Scale $turnover 2 12)
  } else {
    16 * (Clamp (1 - (Scale $turnover 18 40) * 0.45) 0 1)
  }
  $volumeScore = 6 * (Clamp ((Scale $volumeRatio 1 2.8) - [Math]::Max(0, $volumeRatio - 5) * 0.08) 0 1)

  $penalty = 0
  if ($pct -le 0) { $penalty += 12 }
  if ($mainNet -le 0) { $penalty += 18 }
  if ($amount -lt 300000000) { $penalty += 10 }
  if ($turnover -lt 2) { $penalty += 8 }
  if ($amplitude -gt 18) { $penalty += 5 }

  $score = Clamp ($pctScore + $mainScore + $amountScore + $turnoverScore + $volumeScore - $penalty) 0 100

  [ordered]@{
    price = $row.price
    pct = $row.pct
    change = $row.change
    volume = $row.volume
    amount = $row.amount
    amplitude = $row.amplitude
    turnover = $row.turnover
    pe = $row.pe
    volumeRatio = $row.volumeRatio
    code = $row.code
    name = $row.name
    high = $row.high
    low = $row.low
    open = $row.open
    prevClose = $row.prevClose
    marketCap = $row.marketCap
    floatMarketCap = $row.floatMarketCap
    pb = $row.pb
    mainNet = $row.mainNet
    industry = $row.industry
    secid = "$(Get-MarketPrefix $row.code).$($row.code)"
    score = [Math]::Round($score, 1)
    parts = [ordered]@{
      rise = [Math]::Round($pctScore, 1)
      main = [Math]::Round($mainScore, 1)
      amount = [Math]::Round($amountScore, 1)
      turnover = [Math]::Round($turnoverScore, 1)
      volume = [Math]::Round($volumeScore, 1)
    }
    mainRatio = [Math]::Round($mainRatio, 2)
    reasons = @()
  }
}

function Get-Candidates([int]$Limit) {
  $rows = Get-ActiveAsharePool
  $scored = @()
  foreach ($row in $rows) {
    if ($null -eq $row.code -or $null -eq $row.name) { continue }
    if ($row.name -match "ST") { continue }
    if ((Convert-Number $row.amount) -lt 200000000) { continue }
    if ((Convert-Number $row.pct) -le 0) { continue }
    $scored += Get-CandidateScore $row
  }
  return @($scored | Sort-Object -Property { Convert-Number $_.score } -Descending | Select-Object -First $Limit)
}

function Serve-Static($Request, $Response) {
  $path = [uri]::UnescapeDataString($Request.Url.AbsolutePath.TrimStart("/"))
  if ([string]::IsNullOrWhiteSpace($path)) { $path = "index.html" }
  $file = [IO.Path]::GetFullPath((Join-Path $Public $path))
  $publicFull = [IO.Path]::GetFullPath($Public)
  if (-not $file.StartsWith($publicFull)) {
    Send-Text $Response 403 "Forbidden" "text/plain; charset=utf-8"
    return
  }
  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
    Send-Text $Response 404 "Not found" "text/plain; charset=utf-8"
    return
  }
  $ext = [IO.Path]::GetExtension($file).ToLower()
  $type = switch ($ext) {
    ".html" { "text/html; charset=utf-8" }
    ".css" { "text/css; charset=utf-8" }
    ".js" { "application/javascript; charset=utf-8" }
    default { "application/octet-stream" }
  }
  $bytes = [IO.File]::ReadAllBytes($file)
  $Response.StatusCode = 200
  $Response.ContentType = $type
  $Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Response.Close()
}

if ($MyInvocation.InvocationName -ne ".") {
  $listener = [Net.HttpListener]::new()
  $listener.Prefixes.Add($Prefix)
  $listener.Start()

  Write-Host "Sector tape running at $Prefix"
  Write-Host "Press Ctrl+C to stop"
  if (-not $NoOpen) {
    try { Start-Process $Prefix } catch { Write-Host "Open manually: $Prefix" }
  }

  try {
    while ($listener.IsListening) {
      $context = $listener.GetContext()
      $request = $context.Request
      $response = $context.Response
      $path = $request.Url.AbsolutePath

      try {
        if ($path -eq "/api/market") {
          $type = if ($request.QueryString["type"] -eq "industry") { "industry" } else { "concept" }
          $boards = Get-Boards $type "" 500
          $indices = Get-Indices
          $stats = Get-AshareStats
          Send-Json $response 200 @{ ok = $true; type = $type; time = (Get-Date).ToString("s"); data = @{ boards = $boards; indices = $indices; stats = $stats } }
        } elseif ($path -eq "/api/boards") {
          $type = if ($request.QueryString["type"] -eq "industry") { "industry" } else { "concept" }
          $keyword = $request.QueryString["q"]
          $limitText = $request.QueryString["limit"]
          if ([string]::IsNullOrWhiteSpace($limitText)) { $limitText = "160" }
          $limit = [Math]::Min([int]$limitText, 300)
          $rows = Get-Boards $type $keyword $limit
          Send-Json $response 200 @{ ok = $true; type = $type; time = (Get-Date).ToString("s"); data = $rows }
        } elseif ($path -eq "/api/candidates") {
          $limitText = $request.QueryString["limit"]
          if ([string]::IsNullOrWhiteSpace($limitText)) { $limitText = "10" }
          $limit = [Math]::Min([Math]::Max([int]$limitText, 1), 30)
          $rows = Get-Candidates $limit
          Send-Json $response 200 @{ ok = $true; strategy = "UZI: rise + main money + active liquidity"; time = (Get-Date).ToString("s"); data = $rows }
        } elseif ($path -match "^/api/board/([A-Za-z0-9]+)/stocks$") {
          $code = $Matches[1].ToUpper()
          $sort = $request.QueryString["sort"]
          $order = $request.QueryString["order"]
          $rows = Get-BoardStocks $code $sort $order
          Send-Json $response 200 @{ ok = $true; code = $code; time = (Get-Date).ToString("s"); data = $rows }
        } else {
          Serve-Static $request $response
        }
      } catch {
        Send-Json $response 502 @{ ok = $false; error = $_.Exception.Message }
      }
    }
  } finally {
    $listener.Stop()
  }
}
