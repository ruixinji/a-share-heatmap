param(
  [int]$Port = 8787
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Public = Join-Path $Root "public"
$MobilePort = $Port
. (Join-Path $Root "Start-SectorTape.ps1") -Port $MobilePort -NoOpen
$Port = $MobilePort

function Get-LanAddress {
  $addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object {
      $_.IPAddress -notlike "127.*" -and
      $_.IPAddress -notlike "169.254.*" -and
      $_.PrefixOrigin -ne "WellKnown"
    } |
    Sort-Object { if ($_.InterfaceAlias -match "WLAN|Wi-Fi|以太网|Ethernet") { 0 } else { 1 } }

  if ($addresses) { return $addresses[0].IPAddress }
  return "127.0.0.1"
}

function Read-HttpRequest($Stream) {
  $buffer = New-Object byte[] 8192
  $builder = [Text.StringBuilder]::new()
  do {
    $read = $Stream.Read($buffer, 0, $buffer.Length)
    if ($read -le 0) { break }
    [void]$builder.Append([Text.Encoding]::ASCII.GetString($buffer, 0, $read))
  } while ($builder.ToString().IndexOf("`r`n`r`n") -lt 0 -and $builder.Length -lt 65536)

  $text = $builder.ToString()
  $firstLine = ($text -split "`r`n", 2)[0]
  if ($firstLine -notmatch "^(GET)\s+(\S+)\s+HTTP/") { return $null }
  return [uri]::new("http://localhost$($Matches[2])")
}

function Write-HttpResponse($Stream, [int]$Status, [string]$ContentType, [byte[]]$Body) {
  $reason = switch ($Status) {
    200 { "OK" }
    403 { "Forbidden" }
    404 { "Not Found" }
    502 { "Bad Gateway" }
    default { "OK" }
  }
  $headers = "HTTP/1.1 $Status $reason`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $headerBytes = [Text.Encoding]::ASCII.GetBytes($headers)
  $Stream.Write($headerBytes, 0, $headerBytes.Length)
  $Stream.Write($Body, 0, $Body.Length)
}

function Write-Json($Stream, [int]$Status, $Payload) {
  $json = $Payload | ConvertTo-Json -Depth 12 -Compress
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  Write-HttpResponse $Stream $Status "application/json; charset=utf-8" $bytes
}

function Write-Text($Stream, [int]$Status, [string]$Text) {
  $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
  Write-HttpResponse $Stream $Status "text/plain; charset=utf-8" $bytes
}

function Write-Static($Stream, [uri]$Url) {
  $relative = [uri]::UnescapeDataString($Url.AbsolutePath.TrimStart("/"))
  if ([string]::IsNullOrWhiteSpace($relative)) { $relative = "index.html" }
  $file = [IO.Path]::GetFullPath((Join-Path $Public $relative))
  $publicFull = [IO.Path]::GetFullPath($Public)
  if (-not $file.StartsWith($publicFull)) {
    Write-Text $Stream 403 "Forbidden"
    return
  }
  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
    Write-Text $Stream 404 "Not found"
    return
  }

  $ext = [IO.Path]::GetExtension($file).ToLower()
  $type = switch ($ext) {
    ".html" { "text/html; charset=utf-8" }
    ".css" { "text/css; charset=utf-8" }
    ".js" { "application/javascript; charset=utf-8" }
    default { "application/octet-stream" }
  }
  $bytes = [IO.File]::ReadAllBytes($file)
  Write-HttpResponse $Stream 200 $type $bytes
}

function Convert-QueryString([string]$Query) {
  $values = @{}
  if ([string]::IsNullOrWhiteSpace($Query)) { return $values }
  $trimmed = $Query.TrimStart("?")
  foreach ($part in $trimmed -split "&") {
    if ([string]::IsNullOrWhiteSpace($part)) { continue }
    $pieces = $part -split "=", 2
    $key = [uri]::UnescapeDataString($pieces[0])
    $value = if ($pieces.Count -gt 1) { [uri]::UnescapeDataString($pieces[1].Replace("+", " ")) } else { "" }
    $values[$key] = $value
  }
  return $values
}

function Handle-Api($Stream, [uri]$Url) {
  $path = $Url.AbsolutePath
  $query = Convert-QueryString $Url.Query

  if ($path -eq "/api/market") {
    $type = if ($query["type"] -eq "industry") { "industry" } else { "concept" }
    $boards = Get-Boards $type "" 260
    $indices = Get-Indices
    $stats = Get-AshareStats
    Write-Json $Stream 200 @{ ok = $true; type = $type; time = (Get-Date).ToString("s"); data = @{ boards = $boards; indices = $indices; stats = $stats } }
    return
  }

  if ($path -eq "/api/boards") {
    $type = if ($query["type"] -eq "industry") { "industry" } else { "concept" }
    $keyword = $query["q"]
    $limitText = $query["limit"]
    if ([string]::IsNullOrWhiteSpace($limitText)) { $limitText = "160" }
    $limit = [Math]::Min([int]$limitText, 300)
    $rows = Get-Boards $type $keyword $limit
    Write-Json $Stream 200 @{ ok = $true; type = $type; time = (Get-Date).ToString("s"); data = $rows }
    return
  }

  if ($path -match "^/api/board/([A-Za-z0-9]+)/stocks$") {
    $code = $Matches[1].ToUpper()
    $sort = $query["sort"]
    $order = $query["order"]
    $rows = Get-BoardStocks $code $sort $order
    Write-Json $Stream 200 @{ ok = $true; code = $code; time = (Get-Date).ToString("s"); data = $rows }
    return
  }

  Write-Json $Stream 404 @{ ok = $false; error = "Unknown API" }
}

$lan = Get-LanAddress
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Any, $Port)
$listener.Start()

Write-Host ""
Write-Host "A股手机热力图已启动"
Write-Host "电脑打开: http://localhost:$Port/"
Write-Host "手机打开: http://$lan`:$Port/"
Write-Host "注意: 手机和电脑要在同一个 WiFi；Windows 弹窗请选择允许专用网络。"
Write-Host "按 Ctrl+C 停止"
Write-Host ""

try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $url = Read-HttpRequest $stream
      if ($null -eq $url) {
        Write-Text $stream 404 "Bad request"
      } elseif ($url.AbsolutePath.StartsWith("/api/")) {
        try {
          Handle-Api $stream $url
        } catch {
          Write-Json $stream 502 @{ ok = $false; error = $_.Exception.Message }
        }
      } else {
        Write-Static $stream $url
      }
    } finally {
      $client.Close()
    }
  }
} finally {
  $listener.Stop()
}
