const state = {
  type: "concept",
  boards: [],
  selected: null,
  refreshMs: 5000,
  timer: null,
  sort: "pct"
};

const els = {
  status: document.querySelector("#status"),
  indexStrip: document.querySelector("#indexStrip"),
  marketStats: document.querySelector("#marketStats"),
  heatmap: document.querySelector("#heatmap"),
  searchInput: document.querySelector("#searchInput"),
  limitSelect: document.querySelector("#limitSelect"),
  refreshSelect: document.querySelector("#refreshSelect"),
  refreshBtn: document.querySelector("#refreshBtn"),
  boardTitle: document.querySelector("#boardTitle"),
  boardMeta: document.querySelector("#boardMeta"),
  stockList: document.querySelector("#stockList"),
  sortSelect: document.querySelector("#sortSelect")
};

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function numeric(value, fallback = 0) {
  if (value === "-" || value == null || Number.isNaN(Number(value))) return fallback;
  return Number(value);
}

function signed(value, digits = 2) {
  if (value === "-" || value == null || Number.isNaN(Number(value))) return "-";
  const n = Number(value);
  return `${n > 0 ? "+" : ""}${n.toFixed(digits)}`;
}

function money(value) {
  if (value === "-" || value == null || Number.isNaN(Number(value))) return "-";
  const n = Number(value);
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 100000000) return `${sign}${(abs / 100000000).toFixed(2)}亿`;
  if (abs >= 10000) return `${sign}${(abs / 10000).toFixed(1)}万`;
  return `${Math.round(n)}`;
}

function toneClass(value) {
  const n = numeric(value);
  if (n > 0.2) return "up";
  if (n < -0.2) return "down";
  return "flat";
}

function heatColor(value) {
  const pct = numeric(value);
  if (pct >= 7) return "#b8001f";
  if (pct >= 4) return "#9b1426";
  if (pct >= 2) return "#7f1d2c";
  if (pct > 0.2) return "#5c2730";
  if (pct <= -7) return "#067a3c";
  if (pct <= -4) return "#0b6838";
  if (pct <= -2) return "#165637";
  if (pct < -0.2) return "#263f37";
  return "#333943";
}

function setStatus(text, time) {
  const stamp = time ? new Date(time) : new Date();
  els.status.textContent = `${text} · ${stamp.toLocaleTimeString("zh-CN", { hour12: false })}`;
}

async function api(path) {
  const response = await fetch(path, { cache: "no-store" });
  const data = await response.json();
  if (!data.ok) throw new Error(data.error || "请求失败");
  return data;
}

function filteredBoards() {
  const q = els.searchInput.value.trim().toLowerCase();
  const limit = Number(els.limitSelect.value);
  const rows = q
    ? state.boards.filter((row) => `${row.name}${row.code}`.toLowerCase().includes(q))
    : state.boards;
  return rows.slice(0, limit);
}

function renderIndices(rows) {
  els.indexStrip.innerHTML = rows
    .map((row) => `<div class="indexItem">
      <span>${escapeHtml(row.name)}</span>
      <strong class="${toneClass(row.pct)}">${signed(row.pct)}%</strong>
      <small>${signed(row.change)}</small>
    </div>`)
    .join("");
}

function renderStats(stats, boards) {
  const up = boards.filter((row) => numeric(row.pct) > 0.2).length;
  const down = boards.filter((row) => numeric(row.pct) < -0.2).length;
  const flat = boards.length - up - down;
  els.marketStats.innerHTML = `
    <span>全A约 ${stats.total || "-"} 只</span>
    <span class="up">上涨板块 ${up}</span>
    <span class="down">下跌板块 ${down}</span>
    <span>平盘 ${flat}</span>
  `;
}

function renderHeatmap() {
  const rows = filteredBoards();
  if (!rows.length) {
    els.heatmap.innerHTML = '<div class="empty">没有匹配的板块</div>';
    return;
  }

  const amounts = rows.map((row) => Math.max(numeric(row.amount), 1));
  const min = Math.log10(Math.min(...amounts));
  const max = Math.log10(Math.max(...amounts));
  const span = Math.max(max - min, 1);

  els.heatmap.innerHTML = rows
    .map((row) => {
      const amountScore = (Math.log10(Math.max(numeric(row.amount), 1)) - min) / span;
      const grow = Math.round(12 + amountScore * 44);
      const selected = state.selected?.code === row.code ? " selected" : "";
      const rise = numeric(row.riseCount);
      const fall = numeric(row.fallCount);
      const total = rise + fall + numeric(row.flatCount);
      const ratioText = total ? `涨${rise} 跌${fall}` : `成交 ${money(row.amount)}`;
      return `<button class="tile${selected}" type="button" data-code="${escapeHtml(row.code)}" data-name="${escapeHtml(row.name)}"
        style="--grow:${grow}; --tile-bg:${heatColor(row.pct)}">
        <strong>${escapeHtml(row.name)}</strong>
        <span class="${toneClass(row.pct)}">${signed(row.pct)}%</span>
        <small>${escapeHtml(row.code)} · ${ratioText}</small>
      </button>`;
    })
    .join("");

  els.heatmap.querySelectorAll(".tile").forEach((tile) => {
    tile.addEventListener("click", () => {
      state.selected = { code: tile.dataset.code, name: tile.dataset.name };
      renderHeatmap();
      loadStocks();
    });
  });
}

function renderStocks(rows, time) {
  if (!state.selected) return;
  const updateTime = new Date(time).toLocaleTimeString("zh-CN", { hour12: false });
  els.boardTitle.textContent = state.selected.name;
  els.boardMeta.textContent = `${state.selected.code} · ${rows.length} 只成分股 · ${updateTime}`;

  if (!rows.length) {
    els.stockList.innerHTML = '<div class="empty">暂无成分股数据</div>';
    return;
  }

  els.stockList.innerHTML = rows.slice(0, 120).map((row) => `
    <article class="stockRow">
      <div>
        <strong>${escapeHtml(row.name || "-")}</strong>
        <span>${escapeHtml(row.code || "-")} · ${escapeHtml(row.industry || "-")}</span>
      </div>
      <div class="stockNums">
        <b class="${toneClass(row.pct)}">${signed(row.pct)}%</b>
        <span>${money(row.amount)}</span>
      </div>
    </article>
  `).join("");
}

async function loadStocks() {
  if (!state.selected) return;
  els.stockList.innerHTML = '<div class="empty">正在加载成分股...</div>';
  try {
    const data = await api(`/api/board/${state.selected.code}/stocks?sort=${state.sort}&order=desc`);
    renderStocks(data.data, data.time);
  } catch (error) {
    els.stockList.innerHTML = `<div class="empty">成分股加载失败：${escapeHtml(error.message)}</div>`;
  }
}

async function refreshMarket() {
  setStatus("更新中");
  try {
    const data = await api(`/api/market?type=${state.type}`);
    state.boards = data.data.boards;
    if (!state.selected && state.boards.length) {
      state.selected = { code: state.boards[0].code, name: state.boards[0].name };
    }
    renderIndices(data.data.indices);
    renderStats(data.data.stats, state.boards);
    renderHeatmap();
    await loadStocks();
    setStatus("行情已更新", data.time);
  } catch (error) {
    setStatus(`更新失败：${error.message}`);
  }
}

function resetTimer() {
  if (state.timer) clearInterval(state.timer);
  if (state.refreshMs > 0) state.timer = setInterval(refreshMarket, state.refreshMs);
}

function bindEvents() {
  document.querySelectorAll(".segmented button").forEach((button) => {
    button.addEventListener("click", () => {
      state.type = button.dataset.type;
      state.selected = null;
      document.querySelectorAll(".segmented button").forEach((item) => item.classList.toggle("active", item === button));
      refreshMarket();
    });
  });

  els.searchInput.addEventListener("input", () => renderHeatmap());
  els.limitSelect.addEventListener("change", () => renderHeatmap());
  els.refreshBtn.addEventListener("click", refreshMarket);
  els.refreshSelect.addEventListener("change", () => {
    state.refreshMs = Number(els.refreshSelect.value);
    resetTimer();
  });
  els.sortSelect.addEventListener("change", () => {
    state.sort = els.sortSelect.value;
    loadStocks();
  });
}

bindEvents();
refreshMarket();
resetTimer();
