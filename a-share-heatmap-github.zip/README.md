# A Share Heatmap

一个 A 股实时涨跌热力图项目，包含：

- `sector-tape`: 本地/服务器端行情服务和网页热力图
- `wechat-miniprogram`: 微信小程序前端

数据来自东方财富公开行情接口。行情可能延迟，仅作看盘辅助，不构成投资建议。

## 本地网页运行

```powershell
cd sector-tape
npm start
```

打开：

```text
http://localhost:8787
```

Windows 上也可以双击：

```text
sector-tape\手机启动.bat
```

手机和电脑在同一个 WiFi 时，可用电脑局域网 IP 访问。

## 微信小程序

用微信开发者工具导入：

```text
wechat-miniprogram
```

开发阶段可以在微信开发者工具中关闭合法域名校验。正式上线需要：

1. 部署 `sector-tape/server.js` 到公网服务器。
2. 配置 HTTPS 域名。
3. 在微信小程序后台配置 request 合法域名。
4. 修改 `wechat-miniprogram/app.js` 里的 `apiBase`。
5. 把真实小程序 AppID 写入 `wechat-miniprogram/project.config.json`。

## 部署

`sector-tape` 提供了 `Dockerfile`：

```bash
docker build -t a-share-heatmap ./sector-tape
docker run -p 8787:8787 a-share-heatmap
```

## 合规提醒

本项目只展示行情热力图。不要直接提供荐股、跟单、投顾、收费诊股等功能；这些内容可能涉及金融资质和平台审核风险。
