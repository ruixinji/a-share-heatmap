App({
  globalData: {
    // 开发时可以填 http://电脑IP:8788；上线必须换成已备案并配置到小程序后台的 HTTPS 域名。
    apiBase: "http://192.168.100.17:8788",
    adUnitId: ""
  }
});
