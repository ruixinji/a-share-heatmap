const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");

const PORT = Number(process.env.PORT || 8787);
const PUBLIC_DIR = path.join(__dirname, "public");
const EASTMONEY_HEADERS = {
  "User-Agent": "Mozilla/5.0",
  Referer: "https://quote.eastmoney.com/"
};

const BOARD_FIELDS = "f12,f14,f2,f3,f4,f5,f6,f7,f8,f20,f62,f104,f105,f106";
const STOCK_FIELDS = "f12,f14,f2,f3,f4,f5,f6,f7,f8,f9,f10,f15,f16,f17,f18,f20,f21,f23,f62,f100";
const INDEX_FIELDS = "f12,f14,f2,f3,f4,f5,f6";
const A_SHARE_FS = "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23";
const INDEX_SECIDS = "1.000001,0.399001,0.399006,0.000300,0.000905,1.000688";

const FIELD_MAP = {
  f2: "price",
  f3: "pct",
  f4: "change",
  f5: "volume",
  f6: "amount",
  f7: "amplitude",
  f8: "turnover",
  f9: "pe",
  f10: "volumeRatio",
  f12: "code",
  f14: "name",
  f15: "high",
  f16: "low",
  f17: "open",
  f18: "prevClose",
  f20: "marketCap",
  f21: "floatMarketCap",
  f23: "pb",
  f62: "mainNet",
  f100: "industry",
  f104: "riseCount",
  f105: "fallCount",
  f106: "flatCount"
};

const cache = new Map();

function sendJson(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(data));
}

function sendText(res, status, body, type = "text/plain; charset=utf-8") {
  res.writeHead(status, { "Content-Type": type });
  res.end(body);
}

function normalize(row) {
  const out = {};
  for (const [from, to] of Object.entries(FIELD_MAP)) out[to] = row[from];
  return out;
}

function boardFs(type) {
  return type === "industry" ? "m:90+t:2" : "m:90+t:3";
}

function marketPrefix(code) {
  return code?.startsWith("6") ? "1" : "0";
}

async function fetchEastmoney(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, {
      headers: EASTMONEY_HEADERS,
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`Eastmoney ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

async function cached(key, ttlMs, loader) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.time < ttlMs) return hit.data;
  const data = await loader();
  cache.set(key, { time: Date.now(), data });
  return data;
}

async function loadBoards(type) {
  return cached(`boards:${type}`, 5000, async () => {
    const rows = [];
    for (let page = 1; page <= 12; page += 1) {
      const params = new URLSearchParams({
        pn: String(page),
        pz: "100",
        po: "1",
        np: "1",
        fltt: "2",
        invt: "2",
        fid: "f3",
        fs: boardFs(type),
        fields: BOARD_FIELDS
      });
      const data = await fetchEastmoney(`https://push2delay.eastmoney.com/api/qt/clist/get?${params}`);
      const diff = data?.data?.diff || [];
      rows.push(...diff.map(normalize));
      if (rows.length >= Number(data?.data?.total || 0)) break;
    }
    return rows;
  });
}

async function loadBoardStocks(code, sort, order) {
  const sortField = {
    pct: "f3",
    amount: "f6",
    turnover: "f8",
    mainNet: "f62",
    price: "f2"
  }[sort] || "f3";

  return cached(`stocks:${code}:${sort}:${order}`, 5000, async () => {
    const params = new URLSearchParams({
      pn: "1",
      pz: "300",
      po: order === "asc" ? "0" : "1",
      np: "1",
      fltt: "2",
      invt: "2",
      fid: sortField,
      fs: `b:${code}`,
      fields: STOCK_FIELDS
    });
    const data = await fetchEastmoney(`https://push2delay.eastmoney.com/api/qt/clist/get?${params}`);
    return (data?.data?.diff || []).map(normalize).map((row) => ({
      ...row,
      secid: `${marketPrefix(row.code)}.${row.code}`
    }));
  });
}

async function loadIndices() {
  return cached("indices", 3000, async () => {
    const params = new URLSearchParams({
      secids: INDEX_SECIDS,
      ut: "bd1d9ddb04089700cf9c27f6f7426281",
      fltt: "2",
      invt: "2",
      fields: INDEX_FIELDS
    });
    const data = await fetchEastmoney(`https://push2.eastmoney.com/api/qt/ulist.np/get?${params}`);
    return (data?.data?.diff || []).map(normalize);
  });
}

async function loadAshareStats() {
  return cached("market-stats", 3000, async () => {
    const params = new URLSearchParams({
      pn: "1",
      pz: "1",
      po: "1",
      np: "1",
      fltt: "2",
      invt: "2",
      fid: "f3",
      fs: A_SHARE_FS,
      fields: "f3"
    });
    const data = await fetchEastmoney(`https://push2delay.eastmoney.com/api/qt/clist/get?${params}`);
    return { total: Number(data?.data?.total || 0) };
  });
}

function serveStatic(req, res) {
  const pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  const relative = pathname === "/" ? "index.html" : pathname.slice(1);
  const filePath = path.normalize(path.join(PUBLIC_DIR, relative));
  if (!filePath.startsWith(PUBLIC_DIR)) return sendText(res, 403, "Forbidden");

  fs.readFile(filePath, (err, data) => {
    if (err) return sendText(res, 404, "Not found");
    const ext = path.extname(filePath).toLowerCase();
    const type = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "application/javascript; charset=utf-8",
      ".json": "application/json; charset=utf-8"
    }[ext] || "application/octet-stream";
    res.writeHead(200, { "Content-Type": type });
    res.end(data);
  });
}

async function handleApi(req, res, url) {
  try {
    if (url.pathname === "/api/market") {
      const type = url.searchParams.get("type") === "industry" ? "industry" : "concept";
      const [boards, indices, stats] = await Promise.all([loadBoards(type), loadIndices(), loadAshareStats()]);
      return sendJson(res, 200, {
        ok: true,
        type,
        time: new Date().toISOString(),
        data: { boards, indices, stats }
      });
    }

    if (url.pathname === "/api/boards") {
      const type = url.searchParams.get("type") === "industry" ? "industry" : "concept";
      const keyword = (url.searchParams.get("q") || "").trim().toLowerCase();
      const limit = Math.min(Number(url.searchParams.get("limit") || 300), 500);
      const rows = await loadBoards(type);
      const filtered = keyword ? rows.filter((row) => `${row.name}${row.code}`.toLowerCase().includes(keyword)) : rows;
      return sendJson(res, 200, {
        ok: true,
        type,
        time: new Date().toISOString(),
        data: filtered.slice(0, limit)
      });
    }

    const match = url.pathname.match(/^\/api\/board\/([A-Z0-9]+)\/stocks$/i);
    if (match) {
      const code = match[1].toUpperCase();
      const sort = url.searchParams.get("sort") || "pct";
      const order = url.searchParams.get("order") || "desc";
      const rows = await loadBoardStocks(code, sort, order);
      return sendJson(res, 200, {
        ok: true,
        code,
        sort,
        order,
        time: new Date().toISOString(),
        data: rows
      });
    }

    return sendJson(res, 404, { ok: false, error: "Unknown API" });
  } catch (error) {
    return sendJson(res, 502, { ok: false, error: error.message });
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname.startsWith("/api/")) return handleApi(req, res, url);
  return serveStatic(req, res);
});

server.listen(PORT, () => {
  const lan = Object.values(os.networkInterfaces())
    .flat()
    .filter((item) => item && item.family === "IPv4" && !item.internal)
    .map((item) => item.address);
  console.log("");
  console.log("A股手机热力图已启动");
  console.log(`电脑打开: http://localhost:${PORT}/`);
  for (const address of lan) console.log(`手机打开: http://${address}:${PORT}/`);
  console.log("手机和电脑要在同一个 WiFi；如果 Windows 弹窗，请允许专用网络。");
  console.log("按 Ctrl+C 停止");
});
